quote0 () {
echo "Welcome to PGBlitz! Started in December of 2016!" > /pg/var/startup.quote
echo "                                                                 Admin9705" > /pg/var/startup.source
}

quote1 () {
echo "Manbearpig is in there and we all have to kill him while we all have the
chance, I'm cereal!" > /pg/var/startup.quote
echo "                                                       Al Gore ~ SouthPark" > /pg/var/startup.source
}

quote2 () {
echo "There are no stupid answers, just stupid people" > /pg/var/startup.quote
echo "                                                  Mr. Garrison ~ SouthPark" > /pg/var/startup.source
}

quote3 () {
echo "Don't do drugs kids. There is a time and place for everything. It's
called college." > /pg/var/startup.quote
echo "                                                          Chef ~ SouthPark" > /pg/var/startup.source
}

quote4 () {
echo "I left you plenty of food. It's at the supermarket." > /pg/var/startup.quote
echo "                                       Peggy Bundy ~ Married With Children" > /pg/var/startup.source
}

quote5 () {
echo "Dad had one great dream, a dream that had been handed down from
generation to generation of male Bundys: to build their own room and live
separately from their wives. Sadly, they all failed." > /pg/var/startup.quote
echo "                                          Al Bundy ~ Married With Children" > /pg/var/startup.source
}

quote6 () {
echo "Look, Al doesn’t like me blowing smoke in his eggs. What am I supposed to
do? Stop smoking?" > /pg/var/startup.quote
echo "                                       Peggy Bundy ~ Married With Children" > /pg/var/startup.source
}

quote7 () {
echo "I don't care what your doing; it's just the idiotic way that your doing
it!" > /pg/var/startup.quote
echo "                                                 Vincent ~ Final Fantasy 7" > /pg/var/startup.source
}

quote8 () {
echo "Now, we fight like men! And ladies! And ladies who dress like men!" > /pg/var/startup.quote
echo "                                               Gilgamesh ~ Final Fantasy 5" > /pg/var/startup.source
}

quote9 () {
echo "Now, we fight like men! And ladies! And ladies who dress like men!" > /pg/var/startup.quote
echo "                             Gilgamesh ~ Final Fantasy 5 (ROM Translation)" > /pg/var/startup.source
}

quote10 () {
echo "Tomorrow is gonna be just like today, and I know that because today is
just like yesterday!" > /pg/var/startup.quote
echo "                                               Amy Dubanowski ~ SuperStore" > /pg/var/startup.source
}

quote11 () {
echo "You don’t win friends with salad!" > /pg/var/startup.quote
echo "                                        Homer, Bart & Marge ~ The Simpsons" > /pg/var/startup.source
}

quote12 () {
echo "It takes two to lie: one to lie and one to listen." > /pg/var/startup.quote
echo "                                                      Homer ~ The Simpsons" > /pg/var/startup.source
}

quote13 () {
echo "Loneliness and cheeseburgers are a dangerous mix." > /pg/var/startup.quote
echo "                                             Comic Book Guy ~ The Simpsons" > /pg/var/startup.source
}

quote14 () {
echo "Hello, 911? It's Quagmire. Yeah, it's caught in the window this time." > /pg/var/startup.quote
echo "                                                Glen Quagmire ~ Family Guy" > /pg/var/startup.source
}

quote15 () {
echo "My favorite exercise is a cross between a lunge and a crunch...
I call it lunch." > /pg/var/startup.quote
echo "                                                  Anonymous ~ The Internet" > /pg/var/startup.source
}

quote16 () {
echo "McLovin? What kind of stupid name is that Fogell? What... are you
trying to be; an Irish R&B singer?" > /pg/var/startup.quote
echo "                                                           Evan ~ SuperBad" > /pg/var/startup.source
}

quote17 () {
echo "Hello, 911 Emergency? There’s a handsome guy in my bathroom! Hey, wait
a second. Cancel that – it’s only me!" > /pg/var/startup.quote
echo "                                            Johnny Bravo ~ Cartoon Network" > /pg/var/startup.source
}

quote18 () {
echo "Happy-happy, joy-joy! Happy-happy, joy-joy!" > /pg/var/startup.quote
echo "                                            Stimpy ~ The Ren & Stimpy Show" > /pg/var/startup.source
}

quote19 () {
echo "Presenting the Cheese-A-Phone. We can communicate with various cheeses,
regardless of foreign tongue. Go ahead, Ren, say something in Limburger" > /pg/var/startup.quote
echo "                                            Stimpy ~ The Ren & Stimpy Show" > /pg/var/startup.source
}

quote20 () {
echo "The only thing i'm pimping is Sweet Lady Propane, and I'm tricking her
out all over this town!" > /pg/var/startup.quote
echo "                                              Hank Hill ~ King of the Hill" > /pg/var/startup.source
}

quote21 () {
echo "Why would anyone smoke weed when they could just mow a lawn?" > /pg/var/startup.quote
echo "                                              Hank Hill ~ King of the Hill" > /pg/var/startup.source
}

quote22 () {
echo "An ‘F’ in English? Bobby, you speak English!" > /pg/var/startup.quote
echo "                                              Hank Hill ~ King of the Hill" > /pg/var/startup.source
}

quote23 () {
echo "I am the Great Cornholio, I need T.P. for my bunghole" > /pg/var/startup.quote
echo "                                                Beavis ~ Beavis & Butthead" > /pg/var/startup.source
}

quote24 () {
echo "Hey Butt-head, I dreamed I was at school last night. Do you think that
counts for attendance?" > /pg/var/startup.quote
echo "                                                Beavis ~ Beavis & Butthead" > /pg/var/startup.source
}

quote25 () {
echo "Man I tell what, I felt like a one-legged cat try’in to burry turd’s
on a frozen pond out there." > /pg/var/startup.quote
echo "                                                   Tom ~ Beavis & Butthead" > /pg/var/startup.source
}

quote26 () {
echo "Did you know when you eat rump roast you’re eating a cow’s butt?" > /pg/var/startup.quote
echo "                                                Beavis ~ Beavis & Butthead" > /pg/var/startup.source
}

quote27 () {
echo "Did you know when you eat rump roast you’re eating a cow’s butt?" > /pg/var/startup.quote
echo "                                                Beavis ~ Beavis & Butthead" > /pg/var/startup.source
}

quote28 () {
echo "I am Al Gore, and I used to be the next president of the United States
of America!" > /pg/var/startup.quote
echo "                                     Al Gore ~ Speech @ Bocconi University" > /pg/var/startup.source
}

quote29 () {
echo "During my service in the United States Congress I took the initiative
in creating the Internet." > /pg/var/startup.quote
echo "                                         Al Gore ~ 1999 Interview with CNN" > /pg/var/startup.source
}

quote30 () {
echo "If a book about failures doesn’t sell, is it a success?" > /pg/var/startup.quote
echo "                                                            Jerry Seinfeld" > /pg/var/startup.source
}

quote31 () {
echo "If you think nobody cares about you, try missing a couple of payments!" > /pg/var/startup.quote
echo "                                                             Steven Wright" > /pg/var/startup.source
}

quote32 () {
echo "I’m addicted to placebos!" > /pg/var/startup.quote
echo "                                                             Steven Wright" > /pg/var/startup.source
}

quote33 () {
echo "If we’re not meant to have midnight snacks, why is there a light in
the fridge." > /pg/var/startup.quote
echo "                                                  Anonymous ~ The Internet" > /pg/var/startup.source
}

quote34 () {
echo "I could tell that my parents hated me. My bath toys were a toaster and
a radio!" > /pg/var/startup.quote
echo "                                                        Rodney Dangerfield" > /pg/var/startup.source
}

quote35 () {
echo "The quickest way for a parent to get a child’s attention is to sit down
and look comfortable." > /pg/var/startup.quote
echo "                                                           Lane Olinghouse" > /pg/var/startup.source
}

quote36 () {
echo "Donate Today! My biggest adversary is Mrs. Admin for all the time
spent on the project!" > /pg/var/startup.quote
echo "                                                                 Admin9705" > /pg/var/startup.source
}

quote37 () {
echo "Thank you to Sponsors & Donors of the Project! Your assistance
provides continous support in what we do!" > /pg/var/startup.quote
echo "                                                                 Admin9705" > /pg/var/startup.source
}

quote38 () {
echo "Have a funny quote? PM Admin9705 and we will add it!" > /pg/var/startup.quote
echo "                                                            System Message" > /pg/var/startup.source
}

quote39 () {
echo "Greater good?’ I am your wife! I’m the greatest good you’re ever gonna
get!" > /pg/var/startup.quote
echo "                                                   Honey ~ The Incredibles" > /pg/var/startup.source
}

quote40 () {
echo "We get the warhead and we hold the world ransom for…. One million
dollars!" > /pg/var/startup.quote
echo "                    Dr. Evil ~ Austin Powers: International Man of Mystery" > /pg/var/startup.source
}

quote41 () {
echo "Excuse me. I believe you have my stapler." > /pg/var/startup.quote
echo "                                             Milton Waddams ~ Office Space" > /pg/var/startup.source
}

quote42 () {
echo "I learned a long time ago that worrying is like a rocking chair. It
gives you something to do but it doesn’t get you anywhere" > /pg/var/startup.quote
echo "                                Van Wilder ~ National Lampoon’s Van Wilder" > /pg/var/startup.source
}

quote43 () {
echo "It’s not a man purse. It’s called a satchel. Indiana Jones wears one." > /pg/var/startup.quote
echo "                                                Alan Garner ~ The Hangover" > /pg/var/startup.source
}

quote44 () {
echo "As If!" > /pg/var/startup.quote
echo "                                                  Cher Horowitz ~ Clueless" > /pg/var/startup.source
}

quote45 () {
echo "Tina, you fat lard! Come get some Dinner!" > /pg/var/startup.quote
echo "                                                         Napoleon Dynamite" > /pg/var/startup.source
}

quote46 () {
echo "Oh my God, they killed Kenny!" > /pg/var/startup.quote
echo "                                                    Stan Marsh ~ SouthPark" > /pg/var/startup.source
}

quote47 () {
echo "I've got a new recipeeeeeee!" > /pg/var/startup.quote
echo "                                         Ignis Scientia - Final Fantasy XV" > /pg/var/startup.source
}

quote48 () {
echo "I've got a new recipeeeeeee!" > /pg/var/startup.quote
echo "                                         Ignis Scientia - Final Fantasy XV" > /pg/var/startup.source
}

quote49 () {
echo "What is a man? A miserable little pile of secrets." > /pg/var/startup.quote
echo "                              Dracula, Castlevania ~ Symphony of the Night" > /pg/var/startup.source
}

quote50 () {
echo "It's time to kick ass and chew bubble gun... and I'm all out of gum." > /pg/var/startup.quote
echo "                                                Duke Nukem ~ Duke Nukem 3D" > /pg/var/startup.source
}

quote51 () {
echo "Thank You Mario! But our Princess is another castle!" > /pg/var/startup.quote
echo "                                                     Toad(s) ~ NES Mario I" > /pg/var/startup.source
}

quote51 () {
echo "Get over here!" > /pg/var/startup.quote
echo "                                                  Scorpion ~ Mortal Kombat" > /pg/var/startup.source
}

quote52 () {
echo "There are two ways this can go down; and in both of them... you die!" > /pg/var/startup.quote
echo "                                                                Duke Nukem" > /pg/var/startup.source
}

quote53 () {
echo "Lead me, follow me, or get the hell out of my way." > /pg/var/startup.quote
echo "                                        GEN George S. Patton Jr. ~ US Army" > /pg/var/startup.source
}

quote54 () {
echo "If you find yourself in a fair fight, you didn't plan your mission
properly." > /pg/var/startup.quote
echo "                                             COL David Hackworth ~ US Army" > /pg/var/startup.source
}

quote55 () {
echo "Yeah, I'm gonna need you to come in on Saturday. Oh, oh, and I almost
forgot. Ah, I'm also gonna need you to go ahead and come in on Sunday, too." > /pg/var/startup.quote
echo "                                              Bill Lumbergh ~ Office Space" > /pg/var/startup.source
}

quote56 () {
echo "Didn't you get the memo?" > /pg/var/startup.quote
echo "                                              Bill Lumbergh ~ Office Space" > /pg/var/startup.source
}

quote57 () {
echo "No one in this country can pronounce my name right. I mean it's not
that hard. I mean, 'Ni-i-na-najaad', Niinanajaad." > /pg/var/startup.quote
echo "                                                      Samir ~ Office Space" > /pg/var/startup.source
}

quote58 () {
echo "I could set this building on fire." > /pg/var/startup.quote
echo "                                                     Milton ~ Office Space" > /pg/var/startup.source
}

quote59 () {
echo "PC Load Letter? What the f*ck does that mean?." > /pg/var/startup.quote
echo "                                             Michael Bolton ~ Office Space" > /pg/var/startup.source
}

quote60 () {
echo "When you come in on Monday and you're not feeling real well, does
anyone ever say to you 'Sounds like someone has a case of the Mondays?'" > /pg/var/startup.quote
echo "                                              Peter Gibbons ~ Office Space" > /pg/var/startup.source
}

quote61 () {
echo "The thing is Bob it's not that I'm lazy, it's that I just don't care." > /pg/var/startup.quote
echo "                                              Peter Gibbons ~ Office Space" > /pg/var/startup.source
}

quote62 () {
echo "Hello Peter what's happening. I'm gonna need you to go ahead and come
in tomorrow. So if you could be here at around....9 that'd be great." > /pg/var/startup.quote
echo "                                              Bill Lumbergh ~ Office Space" > /pg/var/startup.source
}

quote63 () {
echo "Why does it say paper jam when there is no paper jam? I swear to God
one of these days I am just kicking this piece of sh*t out the window!" > /pg/var/startup.quote
echo "                                                      Samir ~ Office Space" > /pg/var/startup.source
}

quote64 () {
echo "I can't believe you like money too. We should hang out." > /pg/var/startup.quote
echo "                                                      Frito ~ Office Space" > /pg/var/startup.source
}

quote64 () {
echo "I can't believe you like money too. We should hang out." > /pg/var/startup.quote
echo "                                                         Frito ~ Idiocracy" > /pg/var/startup.source
}

quote65 () {
echo "One! Don't you feel dumb. Two! Look at you. Three! Don't you ever make
jokes about me behind my back or else I'll stomp you into the ground." > /pg/var/startup.quote
echo "                                                               Major Payne" > /pg/var/startup.source
}

quote66 () {
echo "Heh, heh, heh" > /pg/var/startup.quote
echo "                                                               Major Payne" > /pg/var/startup.source
}

quote67 () {
echo "You know, somebody actually complimented me on my driving today. They
left a little note on the windscreen, it said ~ Parking Fine." > /pg/var/startup.quote
echo "                                                 Cooper ~ British Comedian" > /pg/var/startup.source
}

quote68 () {
echo "I used to be indecisive but now I am not quite sure." > /pg/var/startup.quote
echo "                                                 Cooper ~ British Comedian" > /pg/var/startup.source
}

quote69 () {
echo "An original idea. That can't be too hard. The library must be full of
them." > /pg/var/startup.quote
echo "                                                    Fry ~ British Comedian" > /pg/var/startup.source
}

quote70 () {
echo "Last night, I dreamt I ate a ten pound marshmallow. When I woke up, the
pillow was gone." > /pg/var/startup.quote
echo "                                                 Cooper ~ British Comedian" > /pg/var/startup.source
}

# END FUNCTIONS ################################################################
num=$( echo $(($RANDOM % 71)) )
quote$num
