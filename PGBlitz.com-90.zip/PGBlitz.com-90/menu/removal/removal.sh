#!/bin/bash
#
# Title:      PGBlitz (Reference Title File)
# Author(s):  Admin9705 - Deiteq
# URL:        https://pgblitz.com - http://github.pgblitz.com
# GNU:        General Public License v3.0
################################################################################
rm -rf /pg/tmp/backup.build 1>/dev/null 2>&1
rm -rf /pg/tmp/backup.list 1>/dev/null 2>&1
rm -rf /pg/tmp/backup.final 1>/dev/null 2>&1

docker ps --format '{{.Names}}' > /pg/tmp/backup.list
sed -i -e "/traefik/d" /pg/tmp/backup.list
sed -i -e "/watchtower/d" /pg/tmp/backup.list
sed -i -e "/wp-*/d" /pg/tmp/backup.list
sed -i -e "/x2go*/d" /pg/tmp/backup.list
sed -i -e "/plexguide/d" /pg/tmp/backup.list
sed -i -e "/cloudplow/d" /pg/tmp/backup.list
sed -i -e "/phlex/d" /pg/tmp/backup.list

#### Commenting Out To Let User See
num=0
while read p; do
let "num++"
echo -n $p >> /pg/tmp/backup.final
echo -n " " >> /pg/tmp/backup.final
  if [ "$num" == 7 ]; then
    num=0
    echo " " >> /pg/tmp/backup.final
  fi
done </pg/tmp/backup.list

running=$(cat /pg/tmp/backup.final)
# If Blank, Exit
if [ "$running" == "" ]; then
tee <<-EOF

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⛔️ WARNING! - No Apps are Running! Exiting!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EOF
sleep 3
exit
fi

# Menu Interface
tee <<-EOF

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🚀 PGBox - App Removal Interface
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠️  Backup Data if Required! Removes Local App Data!

💾 Current Running Apps

$running

💬 Quitting? TYPE > exit
EOF
read -p '🌍 Type APP for QUEUE | Press [ENTER]: ' typed < /dev/tty

if [ "$typed" == "exit" ]; then exit; fi

tcheck=$(echo $running | grep "\<$typed\>")
if [ "$tcheck" == "" ]; then
  tee <<-EOF

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⛔️  WARNING! - Type an Application Name! Case Senstive! Restarting!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EOF
sleep 3
bash /pg/pgblitz/menu/removal/removal.sh
exit
fi

if [ "$typed" == "" ]; then
tee <<-EOF

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⛔️  WARNING! - The App Name Cannot Be Blank!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EOF
sleep 3
bash /pg/traefik/tld.sh
exit
fi

tee <<-EOF

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💎  PASS: UnInstalling - $typed
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EOF
sleep 1.5

tee <<-EOF

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🍖  NOM NOM - Stopping | Removing > $typed Docker Container
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EOF
sleep .5

docker stop $typed 1>/dev/null 2>&1
docker rm $typed 1>/dev/null 2>&1

tee <<-EOF

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🍖  NOM NOM - Removing /pg/data/$typed
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EOF
sleep 1
rm -rf /pg/data/$typed

file="/pg/coreapps/apps/$typed.yml"
if [ -e "$file" ]; then
  check=$(cat /pg/coreapps/apps/$typed.yml | grep '##PG-Community')
    if [ "$check" == "##PG-Community" ]; then rm -r /pg/communityapps/apps/$typed.yml; fi
rm -rf /pg/var/community.app
fi

sleep 1.5

tee <<-EOF

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅️  PASS: Uninstalled - $typed - Exiting!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EOF
sleep 2
